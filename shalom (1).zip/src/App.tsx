import { useState } from 'react';
import { ArrowRight, BookOpen, Check, Copy, Menu, X } from 'lucide-react';
import { ResilientImage } from './components/ResilientImage';
import {
  MENU_ITEMS,
  SCRIPTURE_REFLECTIONS,
  SHALOM_BRAND_ASSETS,
  SHALOM_IMAGES,
} from './data/shalomContent';

type MenuFilter = 'Todo' | 'Bebidas' | 'Panadería';

export default function App() {
  const [selectedVerseId, setSelectedVerseId] = useState<string>(SCRIPTURE_REFLECTIONS[0].id);
  const [copiedVerseId, setCopiedVerseId] = useState<string | null>(null);
  const [menuFilter, setMenuFilter] = useState<MenuFilter>('Todo');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const activeReflection =
    SCRIPTURE_REFLECTIONS.find((item) => item.id === selectedVerseId) ??
    SCRIPTURE_REFLECTIONS[0];

  const visibleMenuCategories: Array<'Bebidas' | 'Panadería'> =
    menuFilter === 'Todo' ? ['Bebidas', 'Panadería'] : [menuFilter];

  const handleCopyVerse = async () => {
    const textToCopy = `${activeReflection.verseText} — ${activeReflection.reference}`;
    try {
      await navigator.clipboard.writeText(textToCopy);
      setCopiedVerseId(activeReflection.id);
      window.setTimeout(() => {
        setCopiedVerseId((current) => (current === activeReflection.id ? null : current));
      }, 2500);
    } catch {
      setCopiedVerseId(activeReflection.id);
      window.setTimeout(() => {
        setCopiedVerseId(null);
      }, 2500);
    }
  };

  const scrollToSection = (sectionId: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="min-h-screen bg-[#F5EFE6] text-[#3B241A]">
      {/* Header: Strict 3-zone Top Bar Contract */}
      <header className="sticky top-0 z-30 bg-[#F5EFE6]/95 backdrop-blur-sm border-b border-[#3B241A]/10">
        <div className="max-w-[1200px] mx-auto px-6 sm:px-8 py-4 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand Wordmark with official circular logo */}
          <a
            href="#inicio"
            onClick={(e) => {
              e.preventDefault();
              scrollToSection('inicio');
            }}
            className="inline-flex items-center gap-3 font-display text-2xl sm:text-3xl font-semibold tracking-tight text-[#3B241A] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#6B1D2F]"
          >
            <ResilientImage
              src={SHALOM_BRAND_ASSETS.logo.src}
              alt={SHALOM_BRAND_ASSETS.logo.alt}
              fallbackTitle="S"
              className="w-10 h-10 rounded-full object-cover border border-[#6B1D2F]/25 shrink-0"
            />
            <span>Shalom</span>
          </a>

          {/* Zone 2: Concise single-line text nav links */}
          <nav
            aria-label="Navegación principal"
            className="hidden md:flex items-center gap-7 text-sm font-medium text-[#5C3D2E]"
          >
            <a
              href="#inicio"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('inicio');
              }}
              className="hover:text-[#6B1D2F] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#6B1D2F]"
            >
              Inicio
            </a>
            <a
              href="#proposito"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('proposito');
              }}
              className="hover:text-[#6B1D2F] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#6B1D2F]"
            >
              Propósito
            </a>
            <a
              href="#palabra"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('palabra');
              }}
              className="hover:text-[#6B1D2F] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#6B1D2F]"
            >
              La Palabra
            </a>
            <a
              href="#menu"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('menu');
              }}
              className="hover:text-[#6B1D2F] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#6B1D2F]"
            >
              Menú
            </a>
          </nav>

          {/* Zone 3: 1 primary action (plus mobile menu button on small viewports) */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => scrollToSection('menu')}
              className="hidden md:inline-flex items-center justify-center px-5 py-2.5 text-xs font-medium tracking-wide text-[#FAF7F2] bg-[#6B1D2F] hover:bg-[#561625] rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#6B1D2F]"
            >
              Ver Menú
            </button>

            <button
              type="button"
              onClick={() => setMobileMenuOpen((prev) => !prev)}
              aria-expanded={mobileMenuOpen}
              aria-label={mobileMenuOpen ? 'Cerrar menú de navegación' : 'Abrir menú de navegación'}
              className="md:hidden inline-flex items-center justify-center w-11 h-11 rounded-lg border border-[#3B241A]/15 text-[#3B241A] hover:bg-[#EBE1D3] transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#6B1D2F]"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile navigation drawer */}
        {mobileMenuOpen ? (
          <div className="md:hidden border-t border-[#3B241A]/10 bg-[#FAF7F2] px-6 py-5">
            <nav aria-label="Navegación móvil" className="flex flex-col gap-3">
              <a
                href="#inicio"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('inicio');
                }}
                className="py-2 text-base font-medium text-[#3B241A] hover:text-[#6B1D2F]"
              >
                Inicio
              </a>
              <a
                href="#proposito"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('proposito');
                }}
                className="py-2 text-base font-medium text-[#3B241A] hover:text-[#6B1D2F]"
              >
                Propósito
              </a>
              <a
                href="#palabra"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('palabra');
                }}
                className="py-2 text-base font-medium text-[#3B241A] hover:text-[#6B1D2F]"
              >
                La Palabra
              </a>
              <a
                href="#menu"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('menu');
                }}
                className="py-2 text-base font-medium text-[#3B241A] hover:text-[#6B1D2F]"
              >
                Menú
              </a>
              <button
                type="button"
                onClick={() => scrollToSection('menu')}
                className="mt-2 w-full py-3 px-5 text-sm font-medium text-[#FAF7F2] bg-[#6B1D2F] hover:bg-[#561625] rounded-lg transition-colors cursor-pointer"
              >
                Ver Menú
              </button>
            </nav>
          </div>
        ) : null}
      </header>

      <main>
        {/* Hero Section */}
        <section id="inicio" className="max-w-[1200px] mx-auto px-6 sm:px-8 pt-10 sm:pt-14 pb-12 sm:pb-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
            {/* Left Editorial Column */}
            <div className="lg:col-span-6 flex flex-col justify-between gap-8 py-2">
              <div className="space-y-6">
                {/* Official Logo Crest + Quiet Metadata */}
                <div className="flex items-center gap-5">
                  <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden border border-[#6B1D2F]/20 bg-[#FAF7F2] shrink-0">
                    <ResilientImage
                      src={SHALOM_BRAND_ASSETS.logo.src}
                      alt={SHALOM_BRAND_ASSETS.logo.alt}
                      fallbackTitle="Shalom"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2 text-xs font-medium tracking-wide text-[#7B5E4D]">
                      <span>Café</span>
                      <span aria-hidden="true">·</span>
                      <span>Paz en Su Palabra</span>
                      <span aria-hidden="true">·</span>
                      <span className="text-[#556645]">Mateo 6:33</span>
                    </div>
                    <p className="font-display italic text-lg text-[#6B1D2F]">
                      «Busca primero el Reino de Dios»
                    </p>
                  </div>
                </div>

                <h1 className="font-display text-[clamp(2.5rem,4.5vw,4rem)] font-medium leading-[1.06] tracking-tight text-[#3B241A] [text-wrap:balance]">
                  Mas que café, una intensión de acercarte a Dios...
                </h1>

                <p className="text-base leading-[1.7] text-[#5C3D2E] max-w-[58ch]">
                  El aroma de Café Shalom te acerca a nuestro deseo de compartir a{' '}
                  <span className="font-script text-[1.5rem] sm:text-[1.65rem] font-normal tracking-[0.06em] text-[#6B1D2F] inline-block align-baseline pl-1">
                    JESUS
                  </span>
                </p>

                {/* Primary Scripture Feature Box (No thick left accent border; clean hairline surround) */}
                <figure className="bg-[#FAF7F2] border border-[#3B241A]/12 rounded-xl p-6 sm:p-7">
                  <blockquote className="space-y-2 text-[#3B241A]">
                    <p className="font-display text-xl sm:text-2xl font-semibold text-[#6B1D2F]">
                      ¿Qué significa Mateo 6:33?
                    </p>
                    <p className="font-display italic text-lg sm:text-xl leading-[1.45] text-[#3B241A]">
                      Antes de preocuparnos por los deseos o planes, necesitamos aprender a
                      buscar la voluntad de Dios. Porque Dios debe ocupar el primer lugar en
                      nuestra vida.
                    </p>
                  </blockquote>
                </figure>
              </div>

              {/* Single Primary CTA + Quiet Secondary Link */}
              <div className="flex flex-wrap items-center gap-6 pt-2">
                <button
                  type="button"
                  onClick={() => scrollToSection('proposito')}
                  className="inline-flex items-center gap-2.5 px-6 py-3 text-sm font-medium text-[#FAF7F2] bg-[#6B1D2F] hover:bg-[#561625] rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#6B1D2F]"
                >
                  <span>Conocer el propósito</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={() => scrollToSection('palabra')}
                  className="inline-flex items-center gap-2 py-2.5 text-sm font-medium text-[#3B241A] hover:text-[#6B1D2F] underline underline-offset-4 decoration-[#3B241A]/30 hover:decoration-[#6B1D2F] transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#6B1D2F]"
                >
                  <BookOpen className="w-4 h-4 text-[#556645]" />
                  <span>Meditar en la Palabra</span>
                </button>
              </div>
            </div>

            {/* Right Visual Column */}
            <div className="lg:col-span-6">
              <div className="h-full rounded-xl overflow-hidden border border-[#3B241A]/12 bg-[#EBE1D3]">
                <ResilientImage
                  src={SHALOM_IMAGES.hero.src}
                  alt={SHALOM_IMAGES.hero.alt}
                  fallbackTitle={SHALOM_IMAGES.hero.fallbackTitle}
                  caption="Un espacio de calma entre el café, el matcha y la luz de la mañana."
                  className="w-full h-full min-h-[320px] lg:min-h-[540px] object-cover"
                />
              </div>
            </div>
          </div>

          {/* Balanced 2-column ethos strip below hero split */}
          <div className="mt-12 pt-8 border-t border-[#3B241A]/12 grid grid-cols-1 sm:grid-cols-2 gap-8 sm:gap-12">
            <div>
              <p className="text-xs font-medium text-[#7B5E4D]">Significado</p>
              <p className="mt-1 font-display text-2xl sm:text-3xl font-medium text-[#3B241A]">
                Shalom (שָׁלוֹם)
              </p>
            </div>
            <div className="sm:border-l sm:border-[#3B241A]/12 sm:pl-12">
              <p className="text-xs font-medium text-[#7B5E4D]">Nuestra Degustación</p>
              <p className="mt-1 font-display text-2xl sm:text-3xl font-medium text-[#3B241A]">
                Bebidas y Panadería
              </p>
              <p className="mt-1 text-xs text-[#5C3D2E]">Café, chocolate, té y pan dulce.</p>
            </div>
          </div>
        </section>

        {/* Section 1: Purpose of the Name */}
        <section
          id="proposito"
          className="border-t border-[#3B241A]/10 bg-[#FAF7F2] py-16 sm:py-24"
        >
          <div className="max-w-[1200px] mx-auto px-6 sm:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-stretch">
              <div className="lg:col-span-5">
                <div className="h-full rounded-xl overflow-hidden border border-[#3B241A]/10 bg-[#EBE1D3]">
                  <ResilientImage
                    src={SHALOM_IMAGES.purpose.src}
                    alt={SHALOM_IMAGES.purpose.alt}
                    fallbackTitle={SHALOM_IMAGES.purpose.fallbackTitle}
                    caption="La Palabra de Dios abierta junto a una taza caliente."
                    className="w-full h-full min-h-[300px] object-cover"
                  />
                </div>
              </div>

              <div className="lg:col-span-7 flex flex-col justify-center gap-6">
                <div className="space-y-4">
                  <p className="text-xs font-medium text-[#6B1D2F]">
                    El propósito de nuestro nombre
                  </p>
                  <h2 className="font-display text-3xl sm:text-4xl font-medium leading-[1.15] tracking-tight text-[#3B241A] [text-wrap:balance]">
                    ¿Por qué llamamos a este lugar Shalom?
                  </h2>
                  <p className="text-base leading-[1.7] text-[#5C3D2E] max-w-[65ch]">
                    En la tradición bíblica, <em>Shalom</em> es mucho más que un saludo amable:
                    describe una vida completa, reconciliada y en reposo bajo el cuidado de
                    Dios. Quisimos que el nombre de esta página y de nuestro café reflejara
                    exactamente lo que anhelamos que experimentes: un encuentro más cercano a
                    ÉL y una tregua frente al afán diario.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Section 2: La Palabra de Dios — Interactive Scripture & Reflection */}
        <section id="palabra" className="py-16 sm:py-24 bg-[#F5EFE6]">
          <div className="max-w-[1200px] mx-auto px-6 sm:px-8">
            <div className="max-w-2xl mb-10 space-y-3">
              <p className="text-xs font-medium text-[#556645]">
                Reflexión en las Escrituras
              </p>
              <h2 className="font-display text-3xl sm:text-4xl font-medium leading-[1.15] tracking-tight text-[#3B241A] [text-wrap:balance]">
                La Palabra de Dios como centro de cada día
              </h2>
              <p className="text-base leading-[1.7] text-[#5C3D2E]">
                Antes de elegir qué beber o qué pendiente resolver, te invitamos a leer con
                calma. Selecciona un pasaje para meditar en el fundamento espiritual de Shalom.
              </p>
            </div>

            {/* Functional Segmented Selector */}
            <div
              role="tablist"
              aria-label="Pasajes bíblicos de Shalom"
              className="inline-flex flex-wrap items-center gap-1.5 p-1.5 bg-[#EBE1D3] rounded-xl border border-[#3B241A]/10 mb-8"
            >
              {SCRIPTURE_REFLECTIONS.map((item) => {
                const isActive = item.id === activeReflection.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    role="tab"
                    aria-selected={isActive}
                    onClick={() => setSelectedVerseId(item.id)}
                    className={`px-4 py-2.5 text-xs sm:text-sm font-medium rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#6B1D2F] ${
                      isActive
                        ? 'bg-[#6B1D2F] text-[#FAF7F2]'
                        : 'text-[#3B241A] hover:bg-[#FAF7F2]/70'
                    }`}
                  >
                    {item.shortLabel}
                  </button>
                );
              })}
            </div>

            {/* Active Passage Editorial Card */}
            <div
              role="tabpanel"
              className="bg-[#FAF7F2] border border-[#3B241A]/12 rounded-xl p-7 sm:p-10 lg:p-12"
            >
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
                <div className="lg:col-span-6 space-y-5">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <span className="text-xs font-medium text-[#6B1D2F]">
                      {activeReflection.bookContext}
                    </span>
                    <button
                      type="button"
                      onClick={handleCopyVerse}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#3B241A] bg-[#EBE1D3]/70 hover:bg-[#EBE1D3] rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#6B1D2F]"
                    >
                      {copiedVerseId === activeReflection.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-[#556645]" />
                          <span>Versículo copiado</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-[#7B5E4D]" />
                          <span>Copiar pasaje</span>
                        </>
                      )}
                    </button>
                  </div>

                  <blockquote className="font-display italic text-2xl sm:text-3xl leading-[1.35] text-[#3B241A]">
                    {activeReflection.verseText}
                  </blockquote>

                  <p className="text-sm font-medium text-[#3B241A]">
                    — {activeReflection.reference}
                  </p>
                </div>

                <div className="lg:col-span-6">
                  <figure className="rounded-xl overflow-hidden border border-[#3B241A]/10 bg-[#FAF7F2]">
                    <ResilientImage
                      src={SHALOM_IMAGES.palabraBibleCoffee.src}
                      alt={SHALOM_IMAGES.palabraBibleCoffee.alt}
                      fallbackTitle={SHALOM_IMAGES.palabraBibleCoffee.fallbackTitle}
                      caption="Dios te espera en todo momento"
                      className="w-full aspect-[4/3] object-cover"
                    />
                    <figcaption className="font-display italic text-lg sm:text-xl text-[#6B1D2F] text-center py-3.5 px-4 border-t border-[#3B241A]/10 bg-[#FAF7F2]">
                      Dios te espera en todo momento
                    </figcaption>
                  </figure>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Section 3: Menú Oficial de Shalom */}
        <section
          id="menu"
          className="border-t border-[#3B241A]/10 bg-[#FAF7F2] py-16 sm:py-24"
        >
          <div className="max-w-[1120px] mx-auto px-6 sm:px-8 space-y-10">
            {/* Centered Header with Light Botanical Ornament */}
            <div className="max-w-xl mx-auto text-center space-y-4">
              <div className="flex items-center justify-center gap-3" aria-hidden="true">
                <span className="h-px w-12 bg-[#6B1D2F]/30" />
                <svg
                  width="22"
                  height="16"
                  viewBox="0 0 22 16"
                  fill="none"
                  className="text-[#556645]"
                >
                  <path
                    d="M11 14C11 14 11 7 4 3C4 9 7.5 13 11 14Z"
                    stroke="currentColor"
                    strokeWidth="1.2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M11 14C11 14 11 7 18 3C18 9 14.5 13 11 14Z"
                    stroke="currentColor"
                    strokeWidth="1.2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                <span className="h-px w-12 bg-[#6B1D2F]/30" />
              </div>

              <h2 className="font-display text-3xl sm:text-5xl font-medium leading-[1.12] tracking-tight text-[#3B241A] [text-wrap:balance]">
                Nuestro Menú
              </h2>

              <p className="text-base leading-[1.7] text-[#5C3D2E]">
                Bebidas calientes preparadas al momento y panadería dulce para disfrutar con
                tranquilidad en nuestra mesa.
              </p>

              {/* Interactive Category Filter */}
              <div className="pt-2 flex justify-center">
                <div
                  role="tablist"
                  aria-label="Filtrar categorías del menú"
                  className="inline-flex flex-wrap items-center gap-1.5 p-1.5 bg-[#EBE1D3] rounded-xl border border-[#3B241A]/10"
                >
                  {(['Todo', 'Bebidas', 'Panadería'] as const).map((category) => {
                    const isActive = menuFilter === category;
                    return (
                      <button
                        key={category}
                        type="button"
                        role="tab"
                        aria-selected={isActive}
                        onClick={() => setMenuFilter(category)}
                        className={`px-4 py-2 text-xs sm:text-sm font-medium rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#6B1D2F] ${
                          isActive
                            ? 'bg-[#6B1D2F] text-[#FAF7F2]'
                            : 'text-[#3B241A] hover:bg-[#FAF7F2]/70'
                        }`}
                      >
                        {category}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Menu Sheet with Light Corner Flourishes */}
            <div className="relative bg-[#F5EFE6]/70 border border-[#3B241A]/12 rounded-2xl p-6 sm:p-10 lg:p-12">
              <span
                aria-hidden="true"
                className="pointer-events-none absolute top-3 left-3 w-4 h-4 border-t border-l border-[#6B1D2F]/35 rounded-tl-md"
              />
              <span
                aria-hidden="true"
                className="pointer-events-none absolute top-3 right-3 w-4 h-4 border-t border-r border-[#6B1D2F]/35 rounded-tr-md"
              />
              <span
                aria-hidden="true"
                className="pointer-events-none absolute bottom-3 left-3 w-4 h-4 border-b border-l border-[#6B1D2F]/35 rounded-bl-md"
              />
              <span
                aria-hidden="true"
                className="pointer-events-none absolute bottom-3 right-3 w-4 h-4 border-b border-r border-[#6B1D2F]/35 rounded-br-md"
              />

              <div
                className={
                  visibleMenuCategories.length === 2
                    ? 'grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-14 items-start'
                    : 'max-w-xl mx-auto'
                }
              >
                {visibleMenuCategories.map((category) => {
                  const items = MENU_ITEMS.filter((item) => item.category === category);
                  return (
                    <div key={category} className="space-y-3">
                      <div className="flex items-center justify-between border-b border-[#6B1D2F]/25 pb-2.5">
                        <h3 className="font-display text-2xl sm:text-3xl font-medium text-[#6B1D2F]">
                          {category}
                        </h3>
                        <span className="text-xs font-medium text-[#556645]">
                          {items.length} {items.length === 1 ? 'opción' : 'opciones'}
                        </span>
                      </div>

                      <div className="divide-y divide-[#3B241A]/10">
                        {items.map((item) => (
                          <div key={item.id} className="py-4">
                            {item.subItems ? (
                              <div className="space-y-3">
                                <div className="space-y-1">
                                  <p className="text-base sm:text-lg font-medium text-[#3B241A]">
                                    {item.name}
                                  </p>
                                  {item.detail ? (
                                    <p className="text-sm text-[#7B5E4D]">{item.detail}</p>
                                  ) : null}
                                </div>
                                <div className="pt-2 border-t border-[#3B241A]/8 space-y-2">
                                  {item.subItems.map((sub) => (
                                    <div
                                      key={sub.name}
                                      className="flex items-baseline justify-between gap-6"
                                    >
                                      <span className="text-sm sm:text-base text-[#3B241A]">
                                        {sub.name}
                                      </span>
                                      <span className="font-display text-lg sm:text-xl font-semibold text-[#6B1D2F] tabular-nums whitespace-nowrap shrink-0">
                                        {sub.price}
                                      </span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            ) : (
                              <div
                                className={`flex justify-between gap-6 ${
                                  item.priceVariants ? 'items-start' : 'items-baseline'
                                }`}
                              >
                                <div className="space-y-1">
                                  <p className="text-base sm:text-lg font-medium text-[#3B241A]">
                                    {item.name}
                                  </p>
                                  {item.detail ? (
                                    <p className="text-sm text-[#7B5E4D]">{item.detail}</p>
                                  ) : null}
                                </div>
                                {item.priceVariants ? (
                                  <div className="flex flex-col items-end gap-1 shrink-0 text-right">
                                    {item.priceVariants.map((variant) => (
                                      <div
                                        key={variant.size}
                                        className="flex items-baseline gap-2.5 whitespace-nowrap"
                                      >
                                        <span className="text-xs sm:text-sm font-medium text-[#7B5E4D]">
                                          {variant.size}:
                                        </span>
                                        <span className="font-display text-lg sm:text-xl font-semibold text-[#6B1D2F] tabular-nums">
                                          {variant.price}
                                        </span>
                                      </div>
                                    ))}
                                  </div>
                                ) : (
                                  <span className="font-display text-xl sm:text-2xl font-semibold text-[#6B1D2F] tabular-nums whitespace-nowrap shrink-0">
                                    {item.price}
                                  </span>
                                )}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Subtle Closing Menu Ornament */}
              <div className="mt-10 pt-6 border-t border-[#3B241A]/10 flex items-center justify-center gap-3 text-xs text-[#7B5E4D]">
                <span className="h-px w-8 bg-[#556645]/40" aria-hidden="true" />
                <span className="font-display italic text-base text-[#5C3D2E]">
                  Hecho con dedicación y paz para ti
                </span>
                <span className="h-px w-8 bg-[#556645]/40" aria-hidden="true" />
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Quiet Editorial Footer */}
      <footer className="border-t border-[#3B241A]/12 bg-[#F5EFE6] py-10 sm:py-12">
        <div className="max-w-[1200px] mx-auto px-6 sm:px-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <ResilientImage
              src={SHALOM_BRAND_ASSETS.logo.src}
              alt={SHALOM_BRAND_ASSETS.logo.alt}
              fallbackTitle="S"
              className="w-12 h-12 rounded-full object-cover border border-[#6B1D2F]/25 shrink-0"
            />
            <div className="space-y-1">
              <p className="font-display text-2xl font-semibold text-[#3B241A]">Shalom</p>
              <p className="text-xs text-[#7B5E4D]">
                Mateo 6:33 · Mas buscad primeramente el reino de Dios y su justicia.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs font-medium text-[#5C3D2E]">
            <a
              href="#inicio"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('inicio');
              }}
              className="hover:text-[#6B1D2F] transition-colors"
            >
              Inicio
            </a>
            <a
              href="#proposito"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('proposito');
              }}
              className="hover:text-[#6B1D2F] transition-colors"
            >
              Propósito
            </a>
            <a
              href="#palabra"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('palabra');
              }}
              className="hover:text-[#6B1D2F] transition-colors"
            >
              La Palabra
            </a>
            <a
              href="#menu"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('menu');
              }}
              className="hover:text-[#6B1D2F] transition-colors"
            >
              Menú
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
