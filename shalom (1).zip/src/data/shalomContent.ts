import heroJesusSketchImg from '../assets/images/hero_jesus_coffee_sketch_1794708874149.jpg';
import purposeBibleImg from '../assets/images/purpose_bible_coffee_1794708007741.jpg';
import craftMatchaImg from '../assets/images/craft_matcha_espresso_1794708007573.jpg';
import sanctuaryCornerImg from '../assets/images/sanctuary_cozy_corner_1794708008352.jpg';
import jesusWaitingCoffeeImg from '../assets/images/jesus_waiting_coffee_table_1794712175918.jpg';

export const SHALOM_IMAGES = {
  hero: {
    src: heroJesusSketchImg,
    alt: 'Dibujo vintage a boceto en tinta sepia sobre papel beige de Jesús sentado con serenidad tomando una taza de café caliente rodeado de ramas de olivo.',
    fallbackTitle: 'Shalom · Mesa de Paz',
  },
  purpose: {
    src: purposeBibleImg,
    alt: 'Biblia abierta junto a una taza artesanal de café negro sobre madera de roble bañada por luz de la mañana.',
    fallbackTitle: 'La Palabra y el Café',
  },
  craft: {
    src: craftMatchaImg,
    alt: 'Latte de matcha ceremonial verde en cerámica artesanal sobre piedra travertino junto a granos de café tostado y servilleta color vino.',
    fallbackTitle: 'Matcha y Café de Especialidad',
  },
  sanctuary: {
    src: sanctuaryCornerImg,
    alt: 'Rincón acogedor de Shalom con muros beige, banca de madera oscura, maceta verde matcha y cojín color vino bajo luz cálida.',
    fallbackTitle: 'Refugio de Quietud',
  },
  palabraBibleCoffee: {
    src: jesusWaitingCoffeeImg,
    alt: 'Ilustración en acuarela y tinta fina de Jesús sentado serenamente en una mesa de café con dos tazas calientes y una silla vacía esperando por ti.',
    fallbackTitle: 'Dios te espera en todo momento',
  },
};

export interface ScriptureReflection {
  id: string;
  reference: string;
  shortLabel: string;
  bookContext: string;
  verseText: string;
  reflectionTitle: string;
  reflectionBody: string[];
  application: string;
}

export const SCRIPTURE_REFLECTIONS: ScriptureReflection[] = [
  {
    id: 'mateo-6-33',
    reference: 'Mateo 6:33',
    shortLabel: 'Mateo 6:33',
    bookContext: 'El Sermón del Monte · Fundamento de Shalom',
    verseText:
      '«Mas buscad primeramente el reino de Dios y su justicia, y todas estas cosas os serán añadidas.»',
    reflectionTitle: 'El orden que devuelve el descanso al alma',
    reflectionBody: [
      'Vivimos rodeados de prisa, pendientes interminables y ruido interior. En medio de esa ansiedad cotidiana, Jesús nos invita a reordenar el corazón: poner primero lo eterno antes que lo urgente.',
      'Shalom nace exactamente de esa promesa. Antes de servir una taza, deseamos ofrecer un recordatorio visible de que cuando buscamos Su reino y Su justicia, Dios mismo sostiene cada detalle de nuestro camino.',
    ],
    application: 'Una pausa consciente antes de comenzar el día.',
  },
  {
    id: 'juan-14-27',
    reference: 'Juan 14:27',
    shortLabel: 'Juan 14:27',
    bookContext: 'Palabras de Jesús · Paz verdadera',
    verseText:
      '«La paz os dejo, mi paz os doy; yo no os la doy como el mundo la da. No se turbe vuestro corazón, ni tenga miedo.»',
    reflectionTitle: 'Una paz que no depende del ruido exterior',
    reflectionBody: [
      'La paz que ofrece el mundo suele ser frágil: dura mientras todo está bajo control. La paz de Cristo —su verdadero Shalom— permanece firme aun en medio de las preguntas sin respuesta.',
      'Cada rincón de nuestra casa está pensado para que sueltes la carga del día, compartas una conversación sincera y descanses en una paz que no se agota.',
    ],
    application: 'Hospitalidad que abraza sin prisas.',
  },
  {
    id: 'isaias-26-3',
    reference: 'Isaías 26:3',
    shortLabel: 'Isaías 26:3',
    bookContext: 'Cántico de confianza · Completa paz',
    verseText:
      '«Tú guardarás en completa paz a aquel cuyo pensamiento en ti persevera; porque en ti ha confiado.»',
    reflectionTitle: 'Shalom, Shalom: plenitud en Su presencia',
    reflectionBody: [
      'En el texto original hebreo, la expresión "completa paz" se escribe literalmente «Shalom, Shalom». Es la repetición que enfatiza una paz entera, íntegra y sin grietas.',
      'Mientras disfrutas el aroma del café recién molido o la suavidad del matcha, nuestra oración es que tu mente encuentre reposo en la fidelidad de la Palabra de Dios.',
    ],
    application: 'Atención plena puesta en la fidelidad de Dios.',
  },
];

export interface PurposePillar {
  number: string;
  title: string;
  subtitle: string;
  description: string;
}

export const PURPOSE_PILLARS: PurposePillar[] = [
  {
    number: '01.',
    title: 'El significado de Shalom',
    subtitle: 'Hebreo · Plenitud y armonía',
    description:
      'Shalom no significa únicamente silencio o ausencia de conflicto; expresa bienestar integral, restauración del corazón y comunión viva con el Creador.',
  },
  {
    number: '02.',
    title: 'La Palabra al centro',
    subtitle: 'Mateo 6:33 · Nuestro norte',
    description:
      'Cada detalle de este espacio existe para honrar a Dios y recordar que Su Palabra es lámpara, consuelo y dirección antes que cualquier afán diario.',
  },
  {
    number: '03.',
    title: 'Café y matcha sin prisa',
    subtitle: 'Ritual acogedor · Mesa compartida',
    description:
      'Creemos que una buena taza preparada con esmero abre espacio para escuchar, leer las Escrituras, orar y construir amistad verdadera.',
  },
];

export const SHALOM_BRAND_ASSETS = {
  logo: {
    src: '/assets/aistudio/WhatsApp_Image_2026-11-14_at_8.09.25_PM_d596e830.jpeg',
    alt: 'Logo oficial de Shalom con taza de café caliente, corazón en el vapor y cita Mateo 6:33.',
    fallbackTitle: 'Shalom · Mateo 6:33',
  },
  menuPoster: {
    src: '/assets/aistudio/WhatsApp_Image_2026-11-14_at_8.10.44_PM_1fde63b1.jpeg',
    alt: 'Menú oficial de Shalom Mateo 6:33 con Bebidas y Panadería.',
    fallbackTitle: 'Menú Oficial de Shalom',
  },
};

export interface MenuItem {
  id: string;
  category: 'Bebidas' | 'Panadería';
  name: string;
  detail?: string;
  price?: string;
  priceVariants?: Array<{ size: string; price: string }>;
  subItems?: Array<{ name: string; price: string }>;
}

export const MENU_ITEMS: MenuItem[] = [
  {
    id: 'cafe-caliente',
    category: 'Bebidas',
    name: 'Café Caliente',
    detail: 'Recién preparado para acompañar un momento de paz.',
    priceVariants: [
      { size: '6 Onzas', price: 'L.20' },
      { size: '8 Onzas', price: 'L.25' },
      { size: '12 Onzas', price: 'L.30' },
    ],
  },
  {
    id: 'chocolate-hershey',
    category: 'Bebidas',
    name: 'Chocolate Hershey Caliente',
    detail: 'Cremoso y reconfortante.',
    priceVariants: [
      { size: '8 Onzas', price: 'L.35' },
      { size: '12 Onzas', price: 'L.40' },
    ],
  },
  {
    id: 'te-variedad',
    category: 'Bebidas',
    name: 'Té',
    detail: 'Variedad de sabores.',
    subItems: [
      { name: 'Té de Manzanilla', price: 'L.18' },
      { name: 'Té de Cúrcuma con Jengibre', price: 'L.20' },
      { name: 'Té verde', price: 'L.20' },
      { name: 'Té de Jamaica', price: 'L.20' },
      { name: 'Té de menta', price: 'L.20' },
    ],
  },
  {
    id: 'pan-de-elote',
    category: 'Panadería',
    name: 'Pan de Elote',
    detail: 'Suave y recién horneado para compartir en la mesa.',
    price: 'L.60',
  },
  {
    id: 'flan',
    category: 'Panadería',
    name: 'Flan',
    detail: 'Cremoso y delicado, preparado en casa.',
    price: 'L.60',
  },
  {
    id: 'magdalena',
    category: 'Panadería',
    name: 'Magdalena',
    detail: 'Esponjosa y tradicional para acompañar tu café.',
    price: 'L.20',
  },
];

