import { useState } from 'react';
import { Coffee } from 'lucide-react';

interface ResilientImageProps {
  src: string;
  alt: string;
  caption?: string;
  className?: string;
  fallbackTitle: string;
}

export function ResilientImage({
  src,
  alt,
  caption,
  className = '',
  fallbackTitle,
}: ResilientImageProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-[#EBE1D3] text-[#3B241A] p-8 text-center border border-[#3B241A]/10 ${className}`}
        role="img"
        aria-label={alt}
      >
        <Coffee className="w-7 h-7 text-[#6B1D2F] mb-3 opacity-80" strokeWidth={1.5} />
        <p className="font-display text-2xl font-medium tracking-tight">{fallbackTitle}</p>
        {caption ? (
          <p className="mt-1.5 text-xs text-[#7B5E4D] max-w-xs">{caption}</p>
        ) : null}
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
    />
  );
}
